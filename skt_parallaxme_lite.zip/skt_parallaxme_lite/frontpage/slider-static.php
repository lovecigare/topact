<?php
global $complete;  
$ImageUrl[] = esc_url(get_template_directory_uri() ."/images/slides/slider1.jpg");

for($i=1; $i<=10; $i++){
	if(!empty($complete['slide_image'.$i])){
		$imgArr[] = $i;
	}
}
require get_template_directory() . '/frontpage/slider.php';
?>

<section id="home_slider">
  <div class="slider-main">
    <?php if(!empty($imgArr)){ ?>
    <div class="slider-wrapper theme-default">
      <div id="slider" class="nivoSlider">
        <?php
			   foreach($imgArr as $val){
				?>
        <img src="<?php echo $complete['slide_image'.$val]; ?>" data-thumb="<?php echo $complete['slide_image'.$val]; ?>" alt="<?php echo strip_tags($complete['slide_title'.$val]); ?>" title="<?php echo esc_attr('#htmlcaption'.$val) ; ?>" />
        <?php } ?>
      </div>
      <?php foreach($imgArr as $val)	{ ?>
      <div id="htmlcaption<?php echo esc_attr($val); ?>" class="nivo-html-caption">
        <div class="nivo-caption-content">
          <?php if(!empty($complete['slide_title'.$val])){ ?>
          <div class="title"><?php echo $complete['slide_title'.$val]; ?></div>
          <?php } ?>
          <?php if(!empty($complete['slide_desc'.$val])){ ?>
          <div class="slidedesc"><?php echo $complete['slide_desc'.$val]; ?></div>
          <?php } ?>
          <?php if(!empty($complete['slide_btn'.$val])){ ?>
          <div class="slidebtn"><a class="slidelink" href="<?php echo $complete['slide_link'.$val]; ?>"><?php echo $complete['slide_btn'.$val]; ?></a></div>
          <?php } ?>
          <?php if(!empty($complete['slide_btn'.$val.'_2'])){ ?>
          <div class="slidebtn slidebtn2"><a class="slidelink slidelink2" href="<?php echo $complete['slide_link'.$val.'_2']; ?>"><?php echo $complete['slide_btn'.$val.'_2']; ?></a></div>
          <?php } ?>
        </div>
      </div>
      <?php } ?>
    </div>
    <?php }
	else { ?>
    <div class="slider-wrapper slide-temp theme-default">
      <div id="slider" class="nivoSlider">
        <?php foreach($ImageUrl as $val) { ?>
        <img src="<?php echo $val; ?>" data-thumb="<?php echo $val; ?>" alt="" title="#htmlcaption" />
        <?php } ?>
      </div>
      <?php for($i=1; $i<=3; $i++)	{ ?>
      <div id="htmlcaption" class="nivo-html-caption">
        <div class="title"><?php echo '<small>Optimize</small> Your Body'; ?></div>
        <div class="slidedesc">&nbsp;</div>
        <div class="slidebtn">&nbsp;</div>
      </div>
      <?php } ?>
    </div>
    <?php } ?>
  </div>
  <div class="slideshape"> <svg version="1.0" width="1400.000000pt" height="176.000000pt" viewBox="0 0 1400.000000 176.000000" preserveAspectRatio="xMidYMid meet">
   <g transform="translate(0.000000,176.000000) scale(0.100000,-0.100000)" fill="#000000" stroke="none">
      <path d="M4195 1744 c-241 -40 -525 -127 -830 -254 -38 -16 -92 -38 -120 -49 -27 -11 -99 -40 -160 -66 -60 -26 -150 -64 -200 -85 -49 -21 -137 -59 -195 -85 -58 -26 -130 -57 -160 -70 -30 -12 -80 -33 -110 -47 -82 -37 -251 -111 -375 -163 -60 -25 -124 -52 -142 -60 -17 -8 -93 -38 -170 -68 -695 -275 -1130 -377 -1560 -365 l-173 5 0 -219 0 -218 7000 0 7000 0 0 185 0 185 -22 -14 c-13 -8 -67 -33 -121 -56 -175 -74 -390 -97 -601 -64 -167 26 -252 55 -526 181 -102 46 -205 94 -230 105 -142 65 -451 163 -620 198 -599 123 -1077 2 -1294 -327 -64 -96 -127 -72 -485 185 -75 55 -321 215 -396 259 -256 149 -555 260 -835 310 -139 24 -178 27 -380 27 -197 0 -244 -4 -380 -27 -159 -27 -376 -85 -511 -137 -484 -185 -895 -205 -1267 -60 -188 72 -305 137 -572 314 -492 326 -701 424 -1025 482 -102 18 -429 17 -540 -2z" />
   </g>
</svg> </div>
</section>
