<?php
 /**
 * The ADMIN functions for SKT Parallaxme Lite
 *
 * Stores all the admin functions of the template.
 *
 * @package SKT Parallaxme Lite
 * 
 * @since SKT Parallaxme Lite 1.0
 */
 


/**************** LOAD RAW CSS & JS ON BACKEND ****************/
add_action('admin_head', 'complete_editor_fix');

function complete_editor_fix() {}