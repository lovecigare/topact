<?php
 /**
 * The WOOCOMMERCE functions for SKT Parallaxme Lite
 *
 * Stores all the Woocommerce functions of the template.
 *
 * @package SKT Parallaxme Lite
 * 
 * @since SKT Parallaxme Lite 1.0
 */

//DETECT Woocommerce SHOP PAGES
function complete_shop_page_title() { 
return false; 
} 
add_filter('woocommerce_show_page_title', 'complete_shop_page_title');

function complete_is_woocommerce_page () {
        if(  function_exists ( "is_woocommerce" ) && is_woocommerce()){
                return true;
        }
        $woocommerce_keys   =   array ( "woocommerce_shop_page_id" ,
                                        "woocommerce_terms_page_id" ,
                                        "woocommerce_cart_page_id" ,
                                        "woocommerce_checkout_page_id" ,
                                        "woocommerce_pay_page_id" ,
                                        "woocommerce_thanks_page_id" ,
                                        "woocommerce_myaccount_page_id" ,
                                        "woocommerce_edit_address_page_id" ,
                                        "woocommerce_view_order_page_id" ,
                                        "woocommerce_change_password_page_id" ,
                                        "woocommerce_logout_page_id" ,
                                        "woocommerce_lost_password_page_id" ) ;
        foreach ( $woocommerce_keys as $wc_page_id ) {
                if ( get_the_ID () == get_option ( $wc_page_id , 0 ) ) {
                        return true ;
                }
        }
        return false;
}



?>